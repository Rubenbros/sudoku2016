package aima.gui.demo.search;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import aima.core.agent.Action;
import aima.core.agent.impl.DynamicAction;
import aima.core.util.datastructure.XYLocation;

/**
 * @author Ravi Mohan
 * @author R. Lunde
 */
public class FichasBoard {

	public static Action LEFT = new DynamicAction("Left");

	public static Action RIGHT = new DynamicAction("Right");

	public static Action DLEFT = new DynamicAction("Dleft");

	public static Action DRIGHT = new DynamicAction("Dright");
	
	public static Action TLEFT = new DynamicAction("Tleft");

	public static Action TRIGHT = new DynamicAction("Tright");

	private char[] state;

	//
	// PUBLIC METHODS
	//

	public FichasBoard() {
		state = new char[] { 'B', 'B', 'B', ' ', 'V', 'V', 'V'};
	}

	public FichasBoard(char[] state) {
		this.state = new char[state.length];
		System.arraycopy(state, 0, this.state, 0, state.length);
	}

	public FichasBoard(FichasBoard copyBoard) {
		this(copyBoard.getState());
	}

	public char[] getState() {
		return state;
	}

	public char getValueAt(int i) {
		return state[i];
	}

	public void moveGapRight() {
		int gapPos = getGapPosition();
		int newPos = gapPos+1;
		char valueOnRight = getValueAt(newPos);
		setValue(gapPos, valueOnRight);
		setValue(newPos, ' ');

	}

	public void moveGapRight2() {
		int gapPos = getGapPosition();
		int newPos = gapPos+2;
		char valueOnRight = getValueAt(newPos);
		setValue(gapPos, valueOnRight);
		setValue(newPos, ' ');

	}

	public void moveGapRight3() {
		int gapPos = getGapPosition();
		int newPos = gapPos+3;
		char valueOnRight = getValueAt(newPos);
		setValue(gapPos, valueOnRight);
		setValue(newPos, ' ');

	}

	public void moveGapLeft() {
		int gapPos = getGapPosition();
		int newPos = gapPos-1;
		char valueOnRight = getValueAt(newPos);
		setValue(gapPos, valueOnRight);
		setValue(newPos, ' ');

	}

	public void moveGapLeft2() {
		int gapPos = getGapPosition();
		int newPos = gapPos-2;
		char valueOnRight = getValueAt(newPos);
		setValue(gapPos, valueOnRight);
		setValue(newPos, ' ');

	}

	public void moveGapLeft3() {
		int gapPos = getGapPosition();
		int newPos = gapPos-3;
		char valueOnRight = getValueAt(newPos);
		setValue(gapPos, valueOnRight);
		setValue(newPos, ' ');

	}


	public boolean canMoveGap(Action where) {
		boolean retVal = true;
		int absPos = getPositionOf(' ');
		if (where.equals(LEFT))
			retVal = (absPos != 0);
		else if (where.equals(RIGHT))
			retVal = (absPos !=6);
		else if (where.equals(DLEFT))
			retVal = (absPos>1);
		else if (where.equals(DRIGHT))
			retVal = (absPos<5);
		else if (where.equals(TLEFT))
			retVal = (absPos>2);
		else if (where.equals(TRIGHT))
			retVal = (absPos<4);
		return retVal;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FichasBoard other = (FichasBoard) obj;
		if (!Arrays.equals(state, other.state))
			return false;
		return true;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Arrays.hashCode(state);
		return result;
	}

	@Override
	public String toString() {
		return "FichasBoard " + Arrays.toString(state);
	}

	//
	// PRIVATE METHODS
	//


	private int getGapPosition() {
		return getPositionOf(' ');
	}

	private int getPositionOf(char val) {
		int retVal = -1;
		for (int i = 0; i < 7; i++) {
			if (state[i] == val) {
				retVal = i;
			}
		}
		return retVal;
	}

	private void setValue(int x,char val) {
		state[x] = val;

	}
}