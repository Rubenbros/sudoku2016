package aima.gui.demo.search;

import aima.core.search.framework.GoalTest;

/**
 * @author Ravi Mohan
 * 
 */
public class FichasGoalTest implements GoalTest {
	FichasBoard goal = new FichasBoard(new char[] { 'V', 'V', 'V', ' ', 'B', 'B', 'B' });
	public boolean isGoalState(Object state) {
		FichasBoard board = (FichasBoard) state;
		return board.equals(goal);
	}
}