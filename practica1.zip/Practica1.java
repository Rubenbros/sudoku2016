package aima.gui.demo.search;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.swing.table.DefaultTableModel;

import aima.core.agent.Action;
import aima.core.environment.eightpuzzle.EightPuzzleBoard;
import aima.core.environment.eightpuzzle.EightPuzzleFunctionFactory;
import aima.core.environment.eightpuzzle.EightPuzzleGoalTest;
import aima.core.environment.eightpuzzle.ManhattanHeuristicFunction;
import aima.core.environment.eightpuzzle.MisplacedTilleHeuristicFunction;
import aima.core.search.framework.GraphSearch;
import aima.core.search.framework.Problem;
import aima.core.search.framework.ResultFunction;
import aima.core.search.framework.Search;
import aima.core.search.framework.SearchAgent;
import aima.core.search.informed.AStarSearch;
import aima.core.search.informed.GreedyBestFirstSearch;
import aima.core.search.local.SimulatedAnnealingSearch;
import aima.core.search.uninformed.DepthLimitedSearch;
import aima.core.search.uninformed.IterativeDeepeningSearch;

/**
 * @author Ravi Mohan
 * 
 */

public class Practica1 {
	static EightPuzzleBoard boardWithThreeMoveSolution = new EightPuzzleBoard(
			new int[] { 1, 2, 5, 3, 4, 0, 6, 7, 8 });;
	static EightPuzzleBoard random1 = new EightPuzzleBoard(new int[] { 1, 4, 2,
			7, 5, 8, 3, 0, 6 });
	static EightPuzzleBoard extreme = new EightPuzzleBoard(new int[] { 0, 8, 7,
			6, 5, 4, 3, 2, 1 });
	static FichasBoard fichas = new FichasBoard(new char[] { 'B', 'B', 'B', ' ', 'V', 'V', 'V' });
	public static void main(String[] args) {
		long time_start, time_end;
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new DepthLimitedSearch(9), boardWithThreeMoveSolution, "Recursive DLS (9) 3move  -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new DepthLimitedSearch(9), random1, "Recursive DLS (9) random -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new DepthLimitedSearch(9), extreme, "Recursive DLS (9) extrem -->");
		//-----------------------------------------------------------------------------------------------------------
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new IterativeDeepeningSearch(), boardWithThreeMoveSolution, "Iterative DLS (9) 3move  -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new IterativeDeepeningSearch(), random1, "Iterative DLS (9) random -->");
		//eightPuzzleSearch(new IterativeDeepeningSearch(), extreme, "Iterative DLS (9) extrem -->");
		//-----------------------------------------------------------------------------------------------------------
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new GreedyBestFirstSearch(new GraphSearch(),
				new MisplacedTilleHeuristicFunction()), boardWithThreeMoveSolution, "Greedy Best First Search (MisplacedTileHeursitic) (9) 3move  -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new GreedyBestFirstSearch(new GraphSearch(),
				new MisplacedTilleHeuristicFunction()), random1, "Greedy Best First Search (MisplacedTileHeursitic) random -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new GreedyBestFirstSearch(new GraphSearch(),
				new MisplacedTilleHeuristicFunction()), extreme, "Greedy Best First Search (MisplacedTileHeursitic) extrem -->");
		//-----------------------------------------------------------------------------------------------------------
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new GreedyBestFirstSearch(new GraphSearch(),
				new ManhattanHeuristicFunction()), boardWithThreeMoveSolution, "Greedy Best First Search (ManhattanHeursitic) 3move  -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new GreedyBestFirstSearch(new GraphSearch(),
				new ManhattanHeuristicFunction()), random1, "Greedy Best First Search (ManhattanHeursitic) random -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new GreedyBestFirstSearch(new GraphSearch(),
				new ManhattanHeuristicFunction()), extreme, "Greedy Best First Search (ManhattanHeursitic) extrem -->");
		//-----------------------------------------------------------------------------------------------------------
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new AStarSearch(new GraphSearch(),
				new MisplacedTilleHeuristicFunction()), boardWithThreeMoveSolution, "AStar Search (MisplacedTileHeursitic) 3move  -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new AStarSearch(new GraphSearch(),
				new MisplacedTilleHeuristicFunction()), random1, "AStar Search (MisplacedTileHeursitic) random -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new AStarSearch(new GraphSearch(),
				new MisplacedTilleHeuristicFunction()), extreme, "AStar Search (MisplacedTileHeursitic) extrem -->");
		//-----------------------------------------------------------------------------------------------------------
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new SimulatedAnnealingSearch(
				new ManhattanHeuristicFunction()), boardWithThreeMoveSolution, "Simulated Annealing 3move  -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new SimulatedAnnealingSearch(
				new ManhattanHeuristicFunction()), random1, "Simulated Annealing random -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new SimulatedAnnealingSearch(
				new ManhattanHeuristicFunction()), extreme, "Simulated Annealing extrem -->");
		//-----------------------------------------------------------------------------------------------------------
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new AStarSearch(new GraphSearch(),
				new ManhattanHeuristicFunction()), boardWithThreeMoveSolution, "AStar Search (ManhattanHeursitic)  -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new AStarSearch(new GraphSearch(),
				new ManhattanHeuristicFunction()), random1, "AStar Search (ManhattanHeursitic) -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		time_start = System.currentTimeMillis();
		eightPuzzleSearch(new AStarSearch(new GraphSearch(),
				new ManhattanHeuristicFunction()), extreme, "AStar Search (ManhattanHeursitic) -->");
		time_end = System.currentTimeMillis();
		System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		//-----------------------------------------------------------------------------------------------------------
		FichasPuzzleSearch(new DepthLimitedSearch(10), fichas, "DepthLimitedSearch");
	}

	private static void FichasPuzzleSearch(Search search, Object stateInitial, String metodo) {
		try {
			//Tiempo de ejecuci�n
			long time_start, time_end;
			time_start = System.currentTimeMillis();
			System.out.print( metodo + " : \n");
			Problem problem = new Problem(stateInitial, FichasBoardFunction
					.getActionsFunction(), FichasBoardFunction
					.getResultFunction(), new FichasGoalTest());
			SearchAgent agent = new SearchAgent(problem, search);
			printActions(agent.getActions());
			System.out.println("\nESTADOS:");
			executeActions(agent.getActions(), problem);
			printInstrumentation(agent.getInstrumentation());
			time_end = System.currentTimeMillis();
			System.out.println("Tiempo de ejecuci�n " + (time_end - time_start) + " milisegundos");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	private static void eightPuzzleSearch(Search search, Object stateInitial, String st) {
		System.out.print(st + " ");
		try {
			Problem problem = new Problem(stateInitial, EightPuzzleFunctionFactory
					.getActionsFunction(), EightPuzzleFunctionFactory
					.getResultFunction(), new EightPuzzleGoalTest());
			SearchAgent agent = new SearchAgent(problem, search);
			printActions(agent.getActions());
			executeActions(agent.getActions(), problem);
			printInstrumentation(agent.getInstrumentation());
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void printInstrumentation(Properties properties) {
		Iterator<Object> keys = properties.keySet().iterator();
		while (keys.hasNext()) {
			String key = (String) keys.next();
			String property = properties.getProperty(key);
			if (key == "pathCost" || key == "nodesExpanded" || key == "nodesGenerated")
			System.out.print(key + ": " + property + " ");
		}
		System.out.println();

	}

	private static void printActions(List<Action> actions) {
		for (int i = 0; i < actions.size(); i++) {
			String action = actions.get(i).toString();
			System.out.println(action);
		}
	}
	
	private static void executeActions(List<Action> actions, Problem problem)
	{
		Object state = problem.getInitialState();
		ResultFunction resultFunction = problem.getResultFunction();
		for (Action action:actions)
		{
			state = resultFunction.result(state, action);
			System.out.println(state);
			System.out.println("-----");
		}
	}
	

}